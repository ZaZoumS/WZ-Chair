#pragma once
#include "stdafx.h"

namespace g_menu
{
	void menu();
}