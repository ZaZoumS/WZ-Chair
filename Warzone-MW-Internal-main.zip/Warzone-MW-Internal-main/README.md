# MW-WZ-Internal

EDUCATIONAL PERPOSES ONLY NOT INDENDED TO BE USED

Outdated MW/WZ Cheat With Menu

A cheat for modern warfare (warzone) game mode. Expect shit code. But it works
THIS IS NOT UPDATED NOR WILL I UPDATE IT FOR YOU

Esp
Bones
Colour
Customisable Aimbot
No recoil
Imgui menu
NO INJECTOR INCLDED
MISC OPTIONS:
FOV, UAV Etc
^ Was using old cbuff method update using info from Mist: https://www.unknowncheats.me/forum/call-of-duty-modern-warfare/496646-mw19-wz-set-dvars.html


If people still want to use it, use it. Or don't.

MEDIA:

![unknown](https://user-images.githubusercontent.com/41522576/166277018-dd9d4388-565d-4e55-9f5d-564d4047a797.png)
![unknown (1)](https://user-images.githubusercontent.com/41522576/166250014-9ec7a479-21bf-45f6-9c65-3e3a3b5b4f0e.png)
![unknown](https://user-images.githubusercontent.com/41522576/166250033-75a3b7ee-2ffc-4471-bd3b-cab88ded50ce.png)
