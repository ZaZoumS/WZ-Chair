#pragma once
#include "stdafx.h"
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

namespace g_game
{
	void init(ImFont* font);

	/*namespace aim_lock
	{
		void rapid_fire();
	}*/
}
